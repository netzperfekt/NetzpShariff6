# 3.0.1
-  CSS classes renamed to avoid interferences with other FontAwesome versions

# 3.0.0
- Support for SW 6.6
- Update Shariff script to v3.3.0

# 2.1.0
- Update Shariff script to v3.2.2

# 2.0.1
- Asset path for fonts adjusted

# 2.0.0
- Support for SW 6.5
* +++ ATTENTION +++ **Update to SW 6.5**
* First deactivate all plugins (do not uninstall them!).
* Then update the store to SW 6.5
* Then update the plugins to the compatible version for SW 6.5
* Activate all plugins again
* Perform the update for each single plugin (click on the version number of each plugin)
* Shopware has made significant changes in version 6.5. The adaptation of our plugins here was very complex and took a lot of time.
* If something does not work as expected, please contact our plugin support at https://plugins.netzperfekt.de/support.

# 1.1.0
- Change: support for custom product layouts

# 1.0.3
- Fix: sticky buttons also excluded from home page (if set in plugin configuration)
- Version: compatibility with SW 6.4

# 1.0.2
- change: additional services (Mail, Threema, Diaspora)

# 1.0.1
- change: buttons can be excluded on homepage

# 1.0.0
- initial version
- this plugin uses "shariff" (c't) https://github.com/heiseonline/shariff
 
