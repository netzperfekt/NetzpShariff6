# 1.1.0
- Change: support for custom product layouts

# 1.0.3
- Fix: sticky buttons also excluded from home page (if set in plugin configuration)
- Version: compatibility with SW 6.4

# 1.0.2
- change: additional services (Mail, Threema, Diaspora)

# 1.0.1
- change: buttons can be excluded on homepage

# 1.0.0
- initial version
- this plugin uses "shariff" (c't) https://github.com/heiseonline/shariff
 
